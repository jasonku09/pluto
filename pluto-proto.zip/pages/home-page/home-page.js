(function() {
  Polymer({
    is: "home-page"
  });

}).call(this);
