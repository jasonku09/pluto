(function() {
  Polymer({
    is: "feed-tab",
    _computeMoneyStyle: function(amount) {
      if (amount < 0) {
        return 'color:red';
      } else {
        return 'color:green';
      }
    },
    _computeItemAmount: function(amount) {
      if (amount === 0) {
        return '';
      } else if (amount < 0) {
        return '-$' + -amount;
      } else {
        return '+$' + amount;
      }
    },
    properties: {
      feedtemp: {
        type: Array,
        value: [
          {
            name: "Thomas E.",
            timestamp: "June 6th 2015 5:35 PM",
            description: "Saved $15 towards Coachella Ticket",
            avatar: "../../resources/icons/default_profile.png",
            amount: 15
          }, {
            name: "Thomas E.",
            timestamp: "June 6th 2015 5:35 PM",
            description: "Spent $4.78 on Coco Boba ",
            avatar: "../../resources/icons/default_profile.png",
            amount: -4.78
          }, {
            name: "Thomas E.",
            timestamp: "June 6th 2015 5:35 PM",
            description: "Spent $37.89 at Trader Joe's",
            avatar: "../../resources/icons/default_profile.png",
            amount: -37.89
          }, {
            name: "Thomas E.",
            timestamp: "June 6th 2015 5:35 PM",
            description: "Saved $60 towards Rent",
            avatar: "../../resources/icons/default_profile.png",
            amount: 60
          }, {
            name: "Thomas E.",
            timestamp: "June 6th 2015 5:35 PM",
            description: "Successfully saved for Macbook Pro",
            avatar: "../../resources/icons/default_profile.png",
            amount: 0
          }, {
            name: "Thomas E.",
            timestamp: "June 6th 2015 5:35 PM",
            description: "Created a new savings goal",
            avatar: "../../resources/icons/default_profile.png",
            amount: 0
          }, {
            name: "Thomas E.",
            timestamp: "June 6th 2015 5:35 PM",
            description: "Saved 15$ towards Coachella Ticket",
            avatar: "../../resources/icons/default_profile.png",
            amount: 0
          }, {
            name: "Thomas E.",
            timestamp: "June 6th 2015 5:35 PM",
            description: "Saved 15$ towards Coachella Ticket",
            avatar: "../../resources/icons/default_profile.png",
            amount: 0
          }
        ]
      }
    },
    _onUserReturn: function() {
      var i, index, len, ref, user;
      ref = this.users;
      for (index = i = 0, len = ref.length; i < len; index = ++i) {
        user = ref[index];
        this.feedtemp[index].avatar = user.picture.medium;
        this.feedtemp[index].name = user.name.first + " " + user.name.last.slice(0, 1) + ".";
      }
      this.feed = this.feedtemp;
    }
  });

}).call(this);
