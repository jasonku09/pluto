(function() {
  Polymer({
    is: "bank-accounts-page",
    properties: {
      bankAccounts: {
        type: Array,
        notify: true
      }
    },
    _computeAddText: function(bankData) {
      if (bankData.length === 0) {
        return "Add account";
      } else {
        return "Add another account";
      }
    },
    _computeIconColor: function(color) {
      return 'color:' + color;
    },
    _computeChartHidden: function(bankData) {
      if (bankData.length === 0) {
        return true;
      } else {
        return false;
      }
    },
    _computeTotalAssets: function(bankData) {
      var bank, i, len, total;
      total = 0;
      for (i = 0, len = bankData.length; i < len; i++) {
        bank = bankData[i];
        total += parseInt(bank.value);
      }
      return '$ ' + total;
    },
    attached: function() {
      this.bankAccounts = this.bankAccounts || [];
      this._setChartData();
      this.PlaidLink = Plaid.create({
        env: "tartan",
        clientName: "Pluto",
        key: "test_key",
        product: "connect",
        onSuccess: (function(_this) {
          return function(token) {
            return _this._addBankAccount(token);
          };
        })(this)
      });
    },
    _formatAmount: function(amount) {
      return '$ ' + amount;
    },
    _addBankAccount: function(token) {
      var account, amount, color, i, len, name, newBankAccount, ref, tempArray;
      amount = Math.random() * 10000;
      if (token.indexOf('chase') > -1) {
        name = "Chase";
        color = 'rgb(5, 82, 212)';
      } else if (token.indexOf('bofa') > -1) {
        name = "Bank of America";
        color = 'rgb(1, 62, 196)';
      } else if (token.indexOf('wells') > -1) {
        name = "Wells Fargo";
        color = 'rgb(185, 0, 0)';
      } else if (token.indexOf('citi') > -1) {
        name = "Citi";
      } else if (token.indexOf('us') > -1) {
        name = "US Bank";
      } else if (token.indexOf('usaa') > -1) {
        name = "USAA";
      } else if (token.indexOf('amex') > -1) {
        name = "American Express";
      }
      newBankAccount = {
        name: name,
        amount: amount.toFixed(2),
        color: color
      };
      tempArray = [];
      ref = this.bankAccounts;
      for (i = 0, len = ref.length; i < len; i++) {
        account = ref[i];
        tempArray.push(account);
      }
      tempArray.push(newBankAccount);
      this.bankAccounts = tempArray;
      this._setChartData();
    },
    _setChartData: function() {
      var account, dataArray, i, len, ref;
      dataArray = [];
      ref = this.bankAccounts;
      for (i = 0, len = ref.length; i < len; i++) {
        account = ref[i];
        dataArray.push({
          label: account.name,
          value: account.amount,
          color: account.color
        });
      }
      this.bankData = dataArray;
    },
    _onAddTap: function() {
      this.PlaidLink.open();
    },
    _onBackTap: function() {
      return this.router.go('/home', {
        data: {
          accounts: this.bankAccounts
        }
      });
    }
  });

}).call(this);
