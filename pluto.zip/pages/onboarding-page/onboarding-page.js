(function() {
  Polymer({
    is: 'onboarding-page',
    _computeBackHidden: function(selected) {
      if (selected === 0) {
        return true;
      } else {
        return false;
      }
    },
    _computeProgressValue: function(selected) {
      return selected + 1 / 10;
    },
    attached: function() {
      this.selected = 0;
    },
    _onNextTap: function() {
      this.entryAnimation = 'slide-from-right-animation';
      this.exitAnimation = 'slide-left-animation';
      this.selected++;
      if (this.selected === 1) {
        this.$.accountsSummary.UpdateChart();
      }
    },
    _onBackTap: function() {
      this.entryAnimation = 'slide-from-left-animation';
      this.exitAnimation = 'slide-right-animation';
      this.selected--;
    }
  });

}).call(this);
