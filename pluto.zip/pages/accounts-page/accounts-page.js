(function() {
  Polymer({
    is: "accounts-page",
    attached: function() {
      this.userService = this.$.userServices;
      return this.PlaidLink = Plaid.create({
        env: "tartan",
        clientName: "Pluto",
        key: "test_key",
        product: "connect",
        onSuccess: (function(_this) {
          return function(token) {
            return _this.userService.AddAccount(token);
          };
        })(this)
      });
    },
    _onConfirmTap: function() {
      return this.PlaidLink.open();
    }
  });

}).call(this);
