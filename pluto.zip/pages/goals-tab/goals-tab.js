(function() {
  Polymer({
    is: "goals-tab",
    _onItemClick: function() {
      this.$.pages.selected = 1;
    },
    _onAddClick: function() {
      return this.$.pages.selected = 2;
    },
    _onClose: function() {
      this.$.pages.selected = 0;
      return this.$.goalsStorage.reload();
    },
    _onAddFunds: function(e) {
      this.$.addFundsDialog.show();
      return this.selected = e.detail.goal;
    },
    _onFundAdded: function(e) {
      var goal, i, j, len, len1, ref, ref1, tempArray;
      ref = this.goals;
      for (i = 0, len = ref.length; i < len; i++) {
        goal = ref[i];
        if (goal.name === this.selected.name) {
          goal.saved += e.detail.amount;
        }
      }
      tempArray = [];
      ref1 = this.goals;
      for (j = 0, len1 = ref1.length; j < len1; j++) {
        goal = ref1[j];
        tempArray.push(goal);
      }
      this.goals = tempArray;
      this.$.goalsStorage.reload();
    },
    _onWithdrawFunds: function(e) {
      this.selected = e.detail.goal;
      this.withdrawMax = this.selected.saved;
      return this.$.withdrawFundsDialog.show();
    },
    _onFundWithdrawn: function(e) {
      var goal, i, j, len, len1, ref, ref1, tempArray;
      ref = this.goals;
      for (i = 0, len = ref.length; i < len; i++) {
        goal = ref[i];
        if (goal.name === this.selected.name) {
          goal.saved -= e.detail.amount;
        }
      }
      tempArray = [];
      ref1 = this.goals;
      for (j = 0, len1 = ref1.length; j < len1; j++) {
        goal = ref1[j];
        tempArray.push(goal);
      }
      this.goals = tempArray;
      return this.$.goalsStorage.reload();
    }
  });

}).call(this);
