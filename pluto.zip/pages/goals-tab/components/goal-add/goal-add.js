(function() {
  Polymer({
    is: "goal-add",
    behaviors: [Polymer.NeonAnimatableBehavior, Polymer.NeonAnimationRunnerBehavior],
    properties: {
      sharedElements: {
        value: function() {
          return {
            'ripple': this.$.fixed,
            'hero': this.$.toolbar,
            'hero2': this.$.main,
            'ripple2': this.$.fixedtwo
          };
        }
      },
      animationConfig: {
        type: Object,
        value: function() {
          return {
            'entry': [
              {
                name: 'ripple-animation',
                id: 'ripple',
                toPage: this
              }, {
                name: 'ripple-animation',
                id: 'ripple2',
                toPage: this
              }, {
                name: 'fade-in-animation',
                node: this.$.panel,
                timing: {
                  duration: 1000,
                  delay: 600,
                  easing: "cubic-bezier(0.000, 0.785, 0.530, 0.960)"
                }
              }
            ],
            'exit': [
              {
                name: 'fade-out-animation',
                node: this.$.fixed
              }, {
                name: 'fade-out-animation',
                node: this.$.fixedtwo
              }, {
                name: 'scale-down-animation',
                transformOrigin: '90% 75%',
                node: this.$.panel,
                timing: {
                  duration: 800,
                  easing: "cubic-bezier(0.465, 0.000, 0.005, 1.060)"
                }
              }, {
                name: 'fade-out-animation',
                node: this.$.panel,
                timing: {
                  duration: 800,
                  easing: "cubic-bezier(0.465, 0.000, 0.005, 1.060)"
                }
              }
            ]
          };
        }
      }
    },
    initializeGoals: function() {
      this.goals = [];
    },
    _computeBackgroundImage: function(selectedImage) {
      return "background-image: url('" + this.selectedImage + "')";
    },
    _computeBackHidden: function(selected) {
      if (selected !== 0) {
        return false;
      } else {
        return true;
      }
    },
    _computeNextHidden: function(selected) {
      if (selected !== 2) {
        return false;
      } else {
        return true;
      }
    },
    _computeFinishHidden: function(selected) {
      if (selected !== 2) {
        return true;
      } else {
        return false;
      }
    },
    attached: function() {
      this.selected = 0;
      return this.images = ['../../../../resources/images/birthday-gift.jpg', '../../../../resources/images/macbook.jpg', '../../../../resources/images/coachella.jpg', '../../../../resources/images/emergency-fund.jpg', '../../../../resources/images/shoes.jpg', '../../../../resources/images/iphone.png'];
    },
    _selectImage: function(e) {
      this.selectedImage = e.target._templateInstance.item;
    },
    _onExitTap: function() {
      this.fire('close');
      return this.fire('iron-signal', {
        name: "raise"
      });
    },
    _onNextTap: function() {
      this.entryAnimations = 'slide-from-right-animation';
      this.exitAnimations = 'slide-left-animation';
      this.selected++;
    },
    _onBackTap: function() {
      this.entryAnimations = 'slide-from-left-animation';
      this.exitAnimations = 'slide-right-animation';
      this.selected--;
    },
    _onFinishTap: function() {
      var goal, i, len, newGoal, newGoals, ref;
      if (!this.goals) {
        this.goals = [];
      }
      newGoal = {
        name: this.goalName,
        saved: 0,
        total: parseInt(this.goalAmount),
        image: this.selectedImage.substring(11, this.selectedImage.length)
      };
      newGoals = [];
      ref = this.goals;
      for (i = 0, len = ref.length; i < len; i++) {
        goal = ref[i];
        newGoals.push(goal);
      }
      newGoals.push(newGoal);
      this.goals = newGoals;
      this.selected = 0;
      this.goalName = null;
      this.goalAmount = null;
      this.selectedImage = null;
      this._onExitTap();
    },
    _onPictureTap: function() {
      this.$.photoDialog.open();
    }
  });

}).call(this);
