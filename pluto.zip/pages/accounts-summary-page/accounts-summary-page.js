(function() {
  Polymer({
    is: 'accounts-summary-page',
    properties: {
      bankAccounts: {
        type: Array,
        observer: '_onBankAccountsChange'
      }
    },
    _onBankAccountsChange: function() {
      var account, dataArray, _i, _len, _ref;
      dataArray = [];
      _ref = this.bankAccounts;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        account = _ref[_i];
        dataArray.push({
          label: account.name,
          value: account.amount,
          color: account.color
        });
      }
      this.bankData = dataArray;
    },
    UpdateChart: function() {
      this.$.chart.UpdateChart();
    }
  });

}).call(this);
