(function() {
  Polymer({
    is: 'savings-methods-page',
    properties: {
      selectedMethod: {
        observer: '_onMethodChange'
      },
      savingsMethods: {
        value: []
      }
    },
    _formatSavingsString: function(item) {
      if (item.type === 'percentage') {
        return 'Saving ' + item.value + '% of ' + item.span + ' into ' + item.account;
      } else {
        return 'Saving $' + item.value + ' every ' + item.span + ' into ' + item.account;
      }
    },
    _onAddTap: function() {
      this.$.addCollapse.toggle();
    },
    _onBackTap: function() {
      this.router.go('/home');
    },
    _onMethodChange: function() {
      if (this.selectedMethod === 'percentage') {
        this.$.fixedCollapse.opened = false;
        this.$.percentageCollapse.opened = true;
      } else if (this.selectedMethod === 'fixed') {
        this.$.percentageCollapse.opened = false;
        this.$.fixedCollapse.opened = true;
      }
    },
    _onCreateTap: function() {
      var account, newMethod, span;
      if (this.selectedMethod === 'percentage') {
        account = this.$.accountSelectOne.value;
        span = this.$.spanSelectOne.value;
      } else {
        account = this.$.accountSelectTwo.value;
        span = this.$.spanSelectTwo.value;
      }
      newMethod = {
        type: this.selectedMethod,
        value: this.selectedValue,
        account: account,
        span: span,
        totalSaved: 0
      };
      this.push('savingsMethods', newMethod);
      this.$.addCollapse.opened = false;
    }
  });

}).call(this);
