var PlutoMetadata = {
  CoreProAPI: {
    ClientID: "5582fde094aec9e057dbe904",
    Secret: "21f211ae25e37bff58b967ab5ffe41"
  },
  Parse: {
    ClientID: "wyHN7j7ZM8b3sUeGBP6jVXwujNZbYS3roG52yoiX",
    Secret: "2d5bXrkFyNfWJj1LRgZeJj3gEWGVQZF71nP9ww1F"
  }
};

var PlutoEnums = {
  BankType: {
    BofA: "bofa",
    Chase: "chase",
    WellsFargo: "wells",
    Citi: "citi"
  }
}
