(function() {
  Polymer({
    is: 'pluto-chart',
    properties: {
      chartWidth: {
        type: Number
      },
      chartHeight: {
        type: Number
      },
      data: {
        type: Array,
        observer: 'UpdateChart'
      }
    },
    UpdateChart: function(data) {
      var chart, dataArray, dataPoint, i, len, options, ref;
      this.$.chart.style.width = this.chartWidth + 'px';
      this.$.chart.style.height = this.chartHeight + 'px';
      dataArray = [];
      ref = this.data;
      for (i = 0, len = ref.length; i < len; i++) {
        dataPoint = ref[i];
        dataArray.push({
          value: dataPoint.value,
          color: dataPoint.color,
          label: dataPoint.label
        });
      }
      chart = this.$.chart.getContext("2d");
      options = {
        segmentShowStroke: true,
        segmentStrokeColor: "#fff",
        segmentStrokeWidth: 2,
        animationSteps: 100,
        animationEasing: "easeOut",
        animateRotate: true,
        animateScale: false
      };
      return setTimeout((function(_this) {
        return function() {
          _this.myChart = new Chart(chart).Pie(dataArray, options);
          return _this.myChart.update();
        };
      })(this), 100);
    }
  });

}).call(this);
