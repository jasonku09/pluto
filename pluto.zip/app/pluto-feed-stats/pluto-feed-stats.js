(function() {
  Polymer({
    is: "pluto-feed-stats",
    properties: {
      bankAccounts: {
        observer: '_onBankAccountsChange'
      }
    },
    attached: function() {
      this.totalSaved = 780;
      this.totalSpendable = 190;
      this.saved = 0;
      this.spendable = 0;
      this.cash = 0;
      this.checkCash();
      this.userName = Parse.User.current().get('fullname');
    },
    _onBankAccountsChange: function() {
      var account, i, len, ref, total;
      if (!this.bankAccounts) {
        this.totalCash = 0;
        this.totalSaved = 0;
        this.totalSpendable = 0;
        return;
      }
      total = 0;
      ref = this.bankAccounts;
      for (i = 0, len = ref.length; i < len; i++) {
        account = ref[i];
        total += parseInt(account.amount);
      }
      this.totalCash = total;
    },
    checkCash: function() {
      var check;
      check = false;
      if (this.saved < this.totalSaved) {
        this.saved += 10;
        check = true;
      }
      if (this.cash < this.totalCash) {
        this.cash += 100;
        check = true;
      }
      if (this.spendable < this.totalSpendable) {
        this.spendable += 5;
        check = true;
      }
      if (check) {
        return setTimeout(this.checkCash.bind(this, 500));
      }
    },
    incrementCash: function() {
      this.checkCash();
    }
  });

}).call(this);
