(function() {
  Polymer({
    is: 'pluto-add-funds-dialog',
    properties: {
      selectedSource: {
        observer: '_onSelectedSourceChange'
      },
      selectedBank: {
        observer: '_onSelectedBankChange'
      }
    },
    _computeSliderMax: function(selectedSource, selectedBank) {
      var bank, i, len, ref;
      ref = this.bankAccounts;
      for (i = 0, len = ref.length; i < len; i++) {
        bank = ref[i];
        if (bank.name === selectedBank) {
          this.sliderMax = parseInt(bank.amount);
        }
      }
      return 0;
    },
    attached: function() {
      this.selectBank = false;
      this.selectedSource = 'pluto';
    },
    _onConfirmTap: function() {
      this.selectBank = false;
    },
    _closeBankDialog: function() {
      this.selectBank = false;
    },
    _onSelectedSourceChange: function() {
      if (this.selectedSource === 'bank') {
        this.selectBank = true;
      } else {
        this.sliderMax = 1200;
      }
      if (this.addAmount > this.sliderMax) {
        return this.addAmount = this.sliderMax;
      }
    },
    _onSelectedBankChange: function() {
      var bank, i, len, ref;
      ref = this.bankAccounts;
      for (i = 0, len = ref.length; i < len; i++) {
        bank = ref[i];
        if (bank.name === this.selectedBank) {
          this.sliderMax = parseInt(bank.amount);
          return;
        }
      }
      this.sliderMax = 0;
      if (this.addAmount > this.sliderMax) {
        return this.addAmount = this.sliderMax;
      }
    },
    _onValueChange: function() {
      this.addAmount = this.$.slider.immediateValue;
    },
    _onFinishTap: function() {
      this.fire('fund-added', {
        amount: this.addAmount
      });
      this.$.dialog.opened = false;
    },
    _onCancelTap: function() {
      return this.$.dialog.opened = false;
    },
    show: function() {
      return this.$.dialog.opened = true;
    }
  });

}).call(this);
