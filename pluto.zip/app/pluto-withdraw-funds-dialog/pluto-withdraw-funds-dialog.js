(function() {
  Polymer({
    is: 'pluto-withdraw-funds-dialog',
    _onValueChange: function() {
      this.withdrawAmount = this.$.slider.immediateValue;
    },
    _onCancelTap: function() {
      this.$.dialog.opened = false;
    },
    _onConfirmTap: function() {
      this.fire('fund-withdrawn', {
        amount: this.withdrawAmount
      });
      this.$.dialog.opened = false;
    },
    show: function() {
      this.$.dialog.opened = true;
    }
  });

}).call(this);
