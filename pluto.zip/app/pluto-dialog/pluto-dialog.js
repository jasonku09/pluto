(function() {
  Polymer({
    is: 'pluto-dialog',
    behaviors: [Polymer.IronOverlayBehavior]
  });

}).call(this);
