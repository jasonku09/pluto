(function() {
  Polymer({
    is: 'corepro-api',
    properties: {
      client: {
        type: String
      },
      secret: {
        type: String
      },
      environment: {
        type: String
      }
    },
    attached: function() {
      if (!this.environment || this.environment === "development") {
        this.baseUrl = "https://tartan.plaid.com/";
      } else {
        this.baseUrl = "https://api.plaid.com/";
      }
    },
    AddAccount: function(username, password, type) {
      var body, options, promise;
      options = JSON.stringify(options);
      body = this._createBaseBody();
      body.append("username", username);
      body.append("password", password);
      body.append("type", type);
      promise = this.$.ajax.send({
        url: this.baseUrl + "connect",
        method: "POST",
        body: body
      });
      return promise;
    },
    DeleteAccount: function(accessToken) {
      var body, promise;
      body = this._createBaseBody();
      body.append("access_token", accessToken);
      promise = this.$.ajax.send({
        url: this.baseUrl + "connect",
        method: "DELETE",
        body: body
      });
      return promise;
    },
    ExchangeToken: function(publicToken) {
      var body, promise;
      body = this._createBaseBody();
      body.append("public_token", publicToken);
      promise = this.$.ajax.send({
        url: this.baseUrl + "exchange_token",
        method: "POST",
        body: body
      });
      return promise.then(function(response) {
        return response.access_token;
      });
    },
    SendMFAResponse: function(accessToken, mfa) {
      var body, promise;
      body = this._createBaseBody();
      body.append("mfa", mfa);
      body.append("access_token", accessToken);
      promise = this.$.ajax.send({
        url: this.baseUrl + "connect/step",
        method: "POST",
        body: body
      });
      return promise;
    },
    GetTransactions: function(accessToken) {
      var body, promise;
      body = this._createBaseBody();
      body.append("access_token", accessToken);
      promise = this.$.ajax.send({
        url: this.baseUrl + "connect/get",
        method: "GET",
        body: body
      });
      return promise;
    },
    GetBalance: function(accessToken) {
      var body, promise;
      body = this._createBaseBody();
      body.append("access_token", accessToken);
      promise = this.$.ajax.send({
        url: this.baseUrl + "balance",
        method: "GET",
        body: body
      });
      return promise;
    },
    UpdateAccount: function(username, password, accessToken) {
      var body, promise;
      body = this._createBaseBody();
      body.append("username", username);
      body.append("password", password);
      body.append("access_token", accessToken);
      promise = this.$.ajax.send({
        url: this.baseUrl + "connect",
        method: "PATCH",
        body: body
      });
      return promise;
    },
    _createBaseBody: function() {
      var body;
      body = new FormData();
      body.append("client_id", this.client);
      body.append("secret", this.secret);
      return body;
    }
  });

}).call(this);
