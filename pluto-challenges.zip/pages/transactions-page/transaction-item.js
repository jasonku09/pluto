(function() {
  Polymer({
    is: 'transaction-item',
    properties: {
      currentPosition: Number
    },
    attached: function() {
      this.setScrollDirection('y', this.$.item);
      this.currentPosition = 0;
    },
    _formatAmount: function(amount) {
      return amount.toFixed(2);
    },
    _handleTrack: function(e) {
      var newPosition;
      switch (e.detail.state) {
        case 'start':
          return console.log('tracking started!');
        case 'track':
          newPosition = this.currentPosition + e.detail.ddx;
          if (newPosition > 0) {

          } else {
            this.$.item.style.marginLeft = newPosition + 'px';
            this.$.item.style.marginRight = -newPosition + 'px';
            return this.currentPosition += newPosition;
          }
          break;
        case 'end':
          if (this.currentPosition < 50) {
            this.currentPosition = 100;
            this.$.item.style.marginLeft = '-100px';
            return this.$.item.style.marginRight = '100px';
          } else {
            this.currentPosition = 0;
            this.$.item.style.marginLeft = '0';
            return this.$.item.style.marginRight = '0';
          }
      }
    }
  });

}).call(this);
